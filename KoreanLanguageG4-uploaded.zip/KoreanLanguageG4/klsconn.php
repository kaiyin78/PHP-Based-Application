<?php
$host='localhost';
$user='root';
$pass='';
$db='korean';
$link= mysqli_connect($host, $user, $pass, $db);
if (!$link)
die('Connection Failed'. mysqli_connect_error());
	?>
